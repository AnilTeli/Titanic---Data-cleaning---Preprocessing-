# 🚀 Titanic Data Cleaning & Preprocessing

## 📚 AI & ML Internship Task 1

### 🔍 Objective:
Clean and preprocess the Titanic dataset to prepare it for Machine Learning.

---

## 📂 Dataset Used:
**Titanic Dataset**  
[👉 Download Dataset](https://www.kaggle.com/datasets/yasserh/titanic-dataset)

---

## 🛠 Tools & Libraries:
- Python  
- Pandas  
- NumPy  
- Matplotlib  
- Seaborn  
- Scikit-learn

---

## 🔧 Steps Performed:

### 1. Data Import and Exploration
- Loaded dataset using `pandas`
- Explored data types, null values, and basic statistics.

### 2. Handling Missing Values
- Filled missing **Age** with **median**
- Filled missing **Embarked** with **mode**
- Dropped **Cabin** due to excessive missing values.

### 3. Encoding Categorical Variables
- Applied **One-Hot Encoding** to `Sex` and `Embarked` columns.
- Dropped irrelevant features: `Name`, `Ticket`, `PassengerId`.

### 4. Feature Scaling
- Applied **Standardization** to `Age` and `Fare` using `StandardScaler`.

### 5. Outlier Detection and Removal
- Visualized outliers using **boxplots**.
- Removed outliers in `Fare` using the **IQR method**.

---

## 📊 Visualizations:
- Boxplots were used to detect outliers.
- Null value analysis was done.

---

## ✅ Final Output:
- Clean, encoded, and scaled dataset ready for ML model training.

---

## 💡 Key Learnings:
- Importance of data cleaning for model accuracy.
- Techniques for handling missing values.
- Difference between normalization and standardization.
- Outlier detection using visual and statistical methods.
- Encoding techniques for categorical variables.

---

## 📋 Interview Questions Covered:
1. Types of missing data
2. Handling categorical variables
3. Normalization vs. Standardization
4. Outlier detection methods
5. Importance of preprocessing
6. One-Hot Encoding vs. Label Encoding
7. Handling data imbalance
8. Effect of preprocessing on model accuracy

---

## 📤 Submission:
Submitted as per the internship guidelines.  
🔗 **Submission Link:** [Google Form](https://forms.gle/8Gm83s53KbyXs3Ne9)
